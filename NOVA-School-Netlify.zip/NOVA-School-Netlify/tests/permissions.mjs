import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
const sqlite=new DatabaseSync(':memory:');
for(const f of fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync('drizzle/'+f,'utf8'));
let conflict=false;
const db={async batch(statements){sqlite.exec('BEGIN');try{const results=[];for(const st of statements)results.push(await st.run());sqlite.exec('COMMIT');return results}catch(e){sqlite.exec('ROLLBACK');throw e}},prepare(sql){let args=[];return {bind(...a){args=a;return this},async first(){return sqlite.prepare(sql).get(...args)||null},async all(){return {results:sqlite.prepare(sql).all(...args)}},async run(){if(conflict&&sql.startsWith('UPDATE school'))return {meta:{changes:0}};const r=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}}}}}};
let current={userId:'owner',email:'owner@example.test',displayName:'Owner'};
const env={DB:db};globalThis.__novaEnv=env;globalThis.__novaUser=()=>current;
const state={ownerId:'owner',classes:[],students:[],members:[{id:'owner-member',name:'Owner',email:'owner@example.test',role:'admin'}],subjects:[{id:'language',name:'Հայոց լեզու'},{id:'math',name:'Մաթեմատիկա'}],assignments:[],lessons:[],marks:[],schedule:[],audit:[]};sqlite.prepare('INSERT INTO school(id,payload,revision) VALUES(1,?,0)').run(JSON.stringify(state));
async function mod(file){let source=fs.readFileSync(file,'utf8').replace(/import \{env\} from '[^']*server\/runtime';/,'const env=globalThis.__novaEnv;').replace("import {getChatGPTUser} from '../../chatgpt-auth';",'const getChatGPTUser=async()=>globalThis.__novaUser();').replace("import {getAppUser as getChatGPTUser} from '../../app-auth';",'const getChatGPTUser=async()=>globalThis.__novaUser();').replace("import {getAppUser as getChatGPTUser,loginResponse,rateLimit} from '../../app-auth';",'const getChatGPTUser=async()=>globalThis.__novaUser();const {loginResponse,rateLimit}=globalThis.__appAuth;').replace("import {headers} from 'next/headers';",'const headers=async()=>globalThis.__testHeaders;').replace("import {getChatGPTUser as getPlatformUser} from \"../../chatgpt-auth\";",'').replace("import {getChatGPTUser as getPlatformUser} from '../../chatgpt-auth';",'const getPlatformUser=async()=>globalThis.__platformUser;').replace("import {getAppUser,loginResponse,rateLimit,hashToken,sessionCookie} from '../../app-auth';",'const {getAppUser,loginResponse,rateLimit,hashToken,sessionCookie}=globalThis.__appAuth;').replace("import {credential} from '../../teacher-password';",'const {credential}=globalThis.__teacherModule;').replace("import {credential,passwordHash,validPassword} from '../../teacher-password';",'const {credential,passwordHash,validPassword}=globalThis.__teacherModule;').replace("import {staffName} from '../../staff-name';",'const staffName=globalThis.__staffName;').replace("import {credential,teacherAccess} from '../../teacher-password';",'const {credential,teacherAccess}=globalThis.__teacherModule;').replace("import {assessmentKinds} from '../../model';",'const assessmentKinds=globalThis.__assessmentKinds;');const js=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'))}
const staff=await mod('app/staff-name.ts');globalThis.__staffName=staff.staffName;
globalThis.__teacherModule=await mod('app/teacher-password.ts');globalThis.__assessmentKinds=['Ֆորմատիվ','Գործնական','Թեմատիկ','Բանավոր','Գրավոր','Ամփոփիչ'];let teacherPassword='Test-password-123';
globalThis.__testHeaders=new Headers();globalThis.__appAuth=await mod('app/app-auth.ts');
const api=await mod('app/api/school/route.ts'),parents=await mod('app/api/parents/route.ts');
async function get(m=api){const r=await m.GET(new Request('https://test.local/api/school',{headers:teacherPassword?{'X-Nova-Teacher-Password':encodeURIComponent(teacherPassword)}:{}}));return {status:r.status,body:await r.json()}}
async function post(body,m=api,origin='https://test.local'){const r=await m.POST(new Request('https://test.local/api/'+(m===api?'school':'parents'),{method:'POST',headers:{origin,'Content-Type':'application/json',...(teacherPassword?{'X-Nova-Teacher-Password':encodeURIComponent(teacherPassword)}:{})},body:JSON.stringify({...(body.action==='mark'?{kind:'Ֆորմատիվ'}:{}),...body})}));return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')}}
assert.equal(staff.staffName('Անի Սարգսյան',[]),'ani.sargsyan');assert.equal(staff.staffName('Անի Սարգսյան',['ani.sargsyan']),'ani.sargsyan.2');
assert.equal((await post({action:'class',grade:9,letter:'ա'})).status,200);assert.equal((await post({action:'class',grade:9,letter:'բ'})).status,200);assert.equal((await post({action:'class',grade:9,letter:'ա'})).status,400);assert.equal((await post({action:'class',grade:10,letter:'ա'})).status,400);
let s=(await get()).body.state;const ca=s.classes[0].id,cb=s.classes[1].id,subject=s.subjects[0].id,other=s.subjects[1].id;
for(const [name,classId] of [['Աշակերտ Ա',ca],['Աշակերտ Բ',ca],['Աշակերտ Գ',cb]])assert.equal((await post({action:'student',name,classId})).status,200);
s=(await get()).body.state;const st=s.students[0].id,st2=s.students[1].id,st3=s.students[2].id;
assert.equal((await post({action:'member',name:'Անի Սարգսյան',email:'teacher@example.test',role:'teacher',password:teacherPassword})).status,200);assert.equal((await post({action:'member',name:'Student',email:'student@example.test',role:'student',studentId:st})).status,200);
s=(await get()).body.state;const teacher=s.members.find(x=>x.role==='teacher');assert.equal(teacher.username,'ani.sargsyan');
assert.equal((await post({action:'assignment',memberId:teacher.id,classId:ca,subjectId:subject})).status,200);
assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'9'})).status,400);
current={userId:'teacher',email:teacher.email,displayName:'Teacher'};
for(const studentId of [st,st2])assert.equal((await post({action:'mark',studentId,subjectId:subject,date:'2026-11-01',value:'9'})).status,200);
assert.equal((await post({action:'mark',studentId:st3,subjectId:subject,date:'2026-11-01',value:'9'})).status,400);
let fixture=JSON.parse(sqlite.prepare('SELECT payload FROM school WHERE id=1').get().payload);fixture.marks.push({id:'privacy-fixture',studentId:st3,subjectId:subject,date:'2026-11-01',value:'9'});sqlite.prepare('UPDATE school SET payload=? WHERE id=1').run(JSON.stringify(fixture));

current={userId:'teacher',email:teacher.email,displayName:'Teacher'};assert.equal((await post({action:'class',grade:1,letter:'ա'})).status,400);assert.equal((await post({action:'mark',studentId:st,subjectId:other,date:'2026-11-01',value:'8'})).status,400);assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'8'})).status,200);assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'11'})).status,400);assert.equal((await post({action:'lesson',classId:ca,subjectId:subject,date:'2026-11-01',topic:'Թեմա',homework:'Էջ 10'})).status,200);assert.equal((await get()).body.state.classes.length,1);
assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'8',kind:''})).status,400);
assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'8',kind:'Գործնական'})).status,200);
s=(await get()).body.state;let beforeEdit=s.marks.find(x=>x.studentId===st);assert.equal(beforeEdit.kind,'Գործնական');assert.equal(beforeEdit.createdBy,teacher.id);assert(!JSON.stringify(s).includes(teacherPassword));assert(!JSON.stringify(s).includes('PBKDF2'));assert.notEqual(sqlite.prepare('SELECT hash FROM teacher_credentials WHERE member_id=?').get(teacher.id).hash,teacherPassword);
current={userId:'owner',email:'owner@example.test',displayName:'Owner'};
assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'8',kind:'Թեմատիկ'})).status,200);
s=(await get()).body.state;const afterEdit=s.marks.find(x=>x.studentId===st);assert.equal(afterEdit.id,beforeEdit.id);assert.equal(afterEdit.createdBy,teacher.id);assert.equal(afterEdit.updatedBy,'owner-member');assert.equal(afterEdit.kind,'Թեմատիկ');assert(s.audit[0].details.includes('Թեմատիկ'));
assert.equal((await post({action:'teacherPassword',memberId:teacher.id,password:'short'})).status,400);
assert.equal((await post({action:'teacherPassword',memberId:teacher.id,password:'New-password-123'})).status,200);
current={userId:'student',email:'student@example.test',displayName:'Student'};s=(await get()).body.state;assert.equal(s.students.length,1);assert.equal(s.students[0].id,st);assert.equal(s.marks.length,1);assert.equal(s.marks[0].value,'8');assert.equal(s.lessons[0].homework,'Էջ 10');assert.equal(s.audit.length,0);assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'10'})).status,400);
current=null;assert.equal((await get()).status,401);assert.equal((await get(parents)).body.signedIn,false);assert.equal((await post({action:'register'},parents)).status,400);
current={userId:'parent',email:'parent@example.test',displayName:'Parent'};assert.equal((await get()).status,403);
assert.equal((await post({action:'register',name:'Ծնող Ա',childName:'Աշակերտ Ա',classLabel:'9ա',email:'evil@example.test'},parents)).status,200);let own=(await get(parents)).body;assert.equal(own.request.email,current.email);assert.equal(own.mailReady,false);assert.equal(own.request.status,'unverified');assert.equal(own.request.otp_hash,undefined);const rid=own.request.id;
assert.equal((await post({action:'send'},parents)).status,503);
const owner={userId:'owner',email:'owner@example.test',displayName:'Owner'};const parent=current;
current=owner;assert.equal((await post({action:'approveParent',requestId:rid,studentIds:[st]})).status,400);current=parent;
env.RESEND_API_KEY='test-only';env.MAIL_FROM='NOVA <school@example.test>';
let codes=[];globalThis.fetch=async(url,options)=>{assert.equal(url,'https://api.resend.com/emails');const body=JSON.parse(options.body);assert.deepEqual(body.to,[parent.email]);codes.push(body.text.match(/\d{6}/)[0]);return Response.json({id:'mock-receipt'})};
assert.equal((await post({action:'send'},parents)).status,200);assert.equal((await post({action:'send'},parents)).status,429);const firstCode=codes.at(-1);const wrong=firstCode==='000000'?'111111':'000000';
for(let i=0;i<5;i++)assert.equal((await post({action:'verify',code:wrong},parents)).status,400);assert.equal((await post({action:'verify',code:firstCode},parents)).status,429);
const clock=Date.now;let offset=61000;Date.now=()=>clock()+offset;
assert.equal((await post({action:'send'},parents)).status,200);assert.equal((await post({action:'verify',code:codes.at(-1)},parents)).status,200);assert.equal((await get(parents)).body.request.status,'pending');assert.equal((await get()).status,403);assert.equal((await post({action:'verify',code:codes.at(-1)},parents)).status,409);
current=owner;assert.equal((await get(parents)).body.requests[0].status,'pending');assert.equal((await post({action:'approveParent',requestId:rid,studentIds:['invalid']})).status,400);assert.equal((await post({action:'approveParent',requestId:rid,studentIds:[st,st3]})).status,200);
current=parent;s=(await get()).body.state;assert.equal(s.students.length,2);assert(!s.students.some(x=>x.id===st2));assert.equal(s.marks.length,2);assert(!s.marks.some(x=>x.studentId===st2));assert.equal(s.members.length,1);assert.equal(s.audit.length,0);assert.equal((await get(parents)).body.request.status,'approved');assert.equal((await post({action:'mark',studentId:st,subjectId:subject,date:'2026-11-01',value:'10'})).status,400);assert.equal((await post({action:'approveParent',requestId:rid,studentIds:[st2]})).status,400);assert.equal((await post({action:'reject',id:rid},parents)).status,403);
current={userId:'impostor',email:parent.email,displayName:'Impostor'};assert.equal((await get()).status,403);
current=owner;assert.equal((await post({action:'class',grade:1,letter:'ա'},api,'https://evil.test')).status,403);conflict=true;assert.equal((await post({action:'class',grade:1,letter:'ա'})).status,409);conflict=false;
const p=(await get()).body.state.members.find(x=>x.role==='parent');assert.equal((await post({action:'revoke',id:p.id})).status,200);current=parent;assert.equal((await get()).status,403);assert.equal((await get(parents)).body.request.status,'rejected');
current={userId:'expired',email:'expired@example.test',displayName:'Expiry test'};assert.equal((await post({action:'register',name:'Ծնող Բ',childName:'Աշակերտ Բ',classLabel:'9ա'},parents)).status,200);globalThis.fetch=async()=>Response.json({id:'mock'});assert.equal((await post({action:'send'},parents)).status,200);offset+=601000;assert.equal((await post({action:'verify',code:'000000'},parents)).status,400);
Date.now=clock;console.log('PASS: school permissions, teacher username collisions, parent registration/verification, mail disabled, resend cooldown, attempt limit, expiry, one-use code, admin-only approval, multiple-child isolation, identity binding, revocation, CSRF and write conflicts.');
delete env.RESEND_API_KEY;delete env.MAIL_FROM;
env.NOVA_MAIL_SCRIPT_URL='https://script.google.com/macros/s/test-script/exec';
assert.equal((await get(parents)).body.mailReady,false);
env.NOVA_MAIL_SCRIPT_SECRET='s'.repeat(32);
assert.equal((await get(parents)).body.mailReady,true);
for(const mode of ['success','rejected','wrong-receipt','html']){
 current={userId:'script-'+mode,email:mode+'@example.test',displayName:'Script Test'};
 assert.equal((await post({action:'register',name:'Ծնող Գ',childName:'Աշակերտ Գ',classLabel:'9բ'},parents)).status,200);
 let deliveredCode;
 globalThis.fetch=async(url,options)=>{assert.equal(url,env.NOVA_MAIL_SCRIPT_URL);const b=JSON.parse(options.body);assert.equal(b.secret,env.NOVA_MAIL_SCRIPT_SECRET);assert.equal(b.to,current.email);assert.match(b.code,/^\d{6}$/);deliveredCode=b.code;if(mode==='html')return new Response('<html>Sign in</html>');return Response.json({ok:mode!=='rejected',id:mode==='wrong-receipt'?'incorrect':b.requestId})};
 const result=await post({action:'send'},parents);assert.equal(result.status,mode==='success'?200:502);
 assert(!JSON.stringify((await get(parents)).body).includes(env.NOVA_MAIL_SCRIPT_SECRET));
 assert.equal((await post({action:'verify',code:deliveredCode},parents)).status,mode==='success'?200:400);
}
console.log('PASS: Google Script adapter, secret requirement, exact receipt matching, provider rejection, HTML/sign-in response failure and no secret disclosure.');
process.env.ADMIN_EMAIL='owner@example.test';process.env.ADMIN_SETUP_TOKEN='t'.repeat(32);const auth=await mod('app/api/auth/route.ts');
const useCookie=cookie=>{globalThis.__testHeaders=new Headers(cookie?{cookie:cookie.split(';')[0]}:{});};
// Platform headers alone no longer authenticate school users.
useCookie(null);globalThis.__testHeaders.set('oai-authenticated-user-id','owner');assert.equal(await globalThis.__appAuth.getAppUser(),null);
globalThis.__platformUser=null;assert.equal((await post({action:'setup',password:'Admin-password-123'},auth)).status,403);
globalThis.__platformUser={userId:'owner',email:'owner@example.test'};
assert.equal((await get(auth)).body.setupAllowed,true);
let login=await post({action:'setup',email:'owner@example.test',setupToken:process.env.ADMIN_SETUP_TOKEN,password:'Admin-password-123'},auth);assert.equal(login.status,200);assert(login.cookie.includes('HttpOnly'));assert(login.cookie.includes('Secure'));assert(login.cookie.includes('SameSite=Lax'));useCookie(login.cookie);let appUser=await globalThis.__appAuth.getAppUser();assert.equal(appUser.email,'owner@example.test');assert.equal((await get(auth)).body.setupAllowed,false);assert.equal((await post({action:'setup',password:'Another-password'},auth)).status,403);
// Logout invalidates the stored session, not just the browser cookie.
let response=await auth.POST(new Request('https://test.local/api/auth',{method:'POST',headers:{origin:'https://test.local',cookie:login.cookie.split(';')[0],'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})}));assert.equal(response.status,200);assert.equal(await globalThis.__appAuth.getAppUser(),null);
login=await post({action:'login',email:teacher.email,password:'New-password-123'},auth);assert.equal(login.status,200);useCookie(login.cookie);assert.equal((await globalThis.__appAuth.getAppUser()).email,teacher.email);
current={userId:'owner',email:'owner@example.test',displayName:'Owner'};
assert.equal((await post({action:'teacherPassword',memberId:teacher.id,password:'Teacher-final-password'})).status,200);assert.equal(await globalThis.__appAuth.getAppUser(),null);assert.equal((await post({action:'login',email:teacher.email,password:'New-password-123'},auth)).status,401);assert.equal((await post({action:'login',email:teacher.email,password:'Teacher-final-password'},auth)).status,200);
// Parents register without a platform identity and cannot see school data before approval.
current=null;useCookie(null);const signup=await post({action:'register',email:'new-parent@example.test',password:'Parent-password-123',name:'Նոր ծնող',childName:'Աշակերտ Բ',classLabel:'9ա'},parents);assert.equal(signup.status,200);assert(signup.cookie);useCookie(signup.cookie);current=await globalThis.__appAuth.getAppUser();assert.equal(current.email,'new-parent@example.test');assert.equal(current.verified,false);assert.equal((await get()).status,403);
const newRequest=(await get(parents)).body.request;let newCode;globalThis.fetch=async(url,options)=>{const b=JSON.parse(options.body);newCode=b.code;return Response.json({ok:true,id:b.requestId})};assert.equal((await post({action:'send'},parents)).status,200);assert.equal((await post({action:'verify',code:newCode},parents)).status,200);current=await globalThis.__appAuth.getAppUser();assert.equal(current.verified,true);assert.equal((await get()).status,403);
current={userId:'owner',email:'owner@example.test',displayName:'Owner'};assert.equal((await post({action:'approveParent',requestId:newRequest.id,studentIds:[st2]})).status,200);current=await globalThis.__appAuth.getAppUser();assert.equal((await get()).body.state.students[0].id,st2);
assert.equal((await post({action:'login',email:'new-parent@example.test',password:'wrong-pass'},auth)).status,401);let parentLogin=await post({action:'login',email:'new-parent@example.test',password:'Parent-password-123'},auth);assert.equal(parentLogin.status,200);useCookie(parentLogin.cookie);
sqlite.prepare('UPDATE sessions SET expires=0 WHERE email=?').run('new-parent@example.test');assert.equal(await globalThis.__appAuth.getAppUser(),null);
assert.equal((await post({action:'login',email:teacher.email,password:'Teacher-final-password'},auth,'https://evil.test')).status,403);
console.log('PASS: independent email/password login, owner-only one-time setup, secure session cookie, logout, reset session invalidation, parent signup without ChatGPT, verification/approval gates, wrong password, session expiry and CSRF.');
await assert.rejects(()=>globalThis.__appAuth.loginResponse(teacher.email,new Request('https://test.local'),{ok:true},0),/Գաղտնաբառը փոխվել է/);
console.log('PASS: a password reset cannot race with login to mint a valid new session from the old password.');
