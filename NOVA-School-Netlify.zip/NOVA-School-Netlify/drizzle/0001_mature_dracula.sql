CREATE TABLE `parent_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`child_name` text NOT NULL,
	`class_label` text NOT NULL,
	`status` text DEFAULT 'unverified' NOT NULL,
	`otp_hash` text,
	`salt` text,
	`expires` integer DEFAULT 0 NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`sent_at` integer DEFAULT 0 NOT NULL,
	`send_count` integer DEFAULT 0 NOT NULL,
	`window_start` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`verified_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `parent_requests_user_id_unique` ON `parent_requests` (`user_id`);