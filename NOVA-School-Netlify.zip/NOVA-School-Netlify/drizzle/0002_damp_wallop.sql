CREATE TABLE `teacher_credentials` (
	`member_id` text PRIMARY KEY NOT NULL,
	`hash` text NOT NULL,
	`salt` text NOT NULL,
	`failed` integer DEFAULT 0 NOT NULL,
	`locked_until` integer DEFAULT 0 NOT NULL,
	`version` integer DEFAULT 1 NOT NULL
);
