export type Member={id:string;name:string;email:string;role:'admin'|'teacher'|'student'|'parent';studentId?:string;studentIds?:string[];username?:string;userId?:string;passwordSet?:boolean};
export type Student={id:string;name:string;classId:string};
export type School={ownerId:string;classes:{id:string;grade:number;letter:string}[];students:Student[];members:Member[];subjects:{id:string;name:string}[];assignments:{id:string;memberId:string;classId:string;subjectId:string}[];lessons:{id:string;classId:string;subjectId:string;date:string;topic:string;homework:string}[];marks:{id:string;studentId:string;subjectId:string;date:string;value:string;kind?:string;createdBy?:string;createdByName?:string;updatedBy?:string;updatedByName?:string;createdAt?:string;updatedAt?:string}[];schedule:{id:string;classId:string;subjectId:string;day:number;period:number}[];audit:{id:string;date:string;actor:string;action:string;details?:string}[]};
export const className=(c:School['classes'][number])=>`${c.grade}${c.letter}`;

export const assessmentKinds=["Ֆորմատիվ","Գործնական","Թեմատիկ","Բանավոր","Գրավոր","Ամփոփիչ"] as const;
