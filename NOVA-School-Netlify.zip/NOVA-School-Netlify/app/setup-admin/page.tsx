import LoginForm from '../login/login-form';
export default function Page(){return <LoginForm setup/>}
