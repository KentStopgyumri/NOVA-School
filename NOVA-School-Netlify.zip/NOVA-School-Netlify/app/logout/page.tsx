'use client';
import {useEffect} from 'react';
export default function Page(){useEffect(()=>{fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})}).then(()=>window.location.replace('/login'))},[]);return <div className="loading"><p>Դուրս ենք գալիս հաշվից…</p></div>}
