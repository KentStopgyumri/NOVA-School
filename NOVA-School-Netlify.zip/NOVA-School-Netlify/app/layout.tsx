import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'NOVA դպրոց • Օրագիր և մատյան',description:'NOVA դպրոցի էլեկտրոնային օրագիր և մատյան՝ 1–9 դասարանների համար'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="hy"><body>{children}</body></html>}
