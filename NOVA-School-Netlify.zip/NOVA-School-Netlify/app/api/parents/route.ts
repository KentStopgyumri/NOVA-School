import {env} from '../../../server/runtime';
import {getAppUser as getChatGPTUser,loginResponse,rateLimit} from '../../app-auth';
import {credential} from '../../teacher-password';
import type {School} from '../../model';
export const dynamic='force-dynamic';
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
type RequestRow={id:string;user_id:string;email:string;name:string;child_name:string;class_label:string;status:string;otp_hash:string|null;salt:string|null;expires:number;attempts:number;sent_at:number;send_count:number;window_start:number;created_at:string;verified_at:string|null};
const config=()=>{const e=env as unknown as Record<string,string|undefined>;const scriptUrl=e.NOVA_MAIL_SCRIPT_URL;const scriptSecret=e.NOVA_MAIL_SCRIPT_SECRET;const validScript=!!scriptUrl&&/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(scriptUrl);return {key:e.RESEND_API_KEY,from:e.MAIL_FROM,scriptUrl,scriptSecret,scriptReady:validScript&&!!scriptSecret&&scriptSecret.length>=32}};
const mailReady=()=>{const c=config();return c.scriptReady||!!(c.key&&c.from)};
async function school(){const row=await env.DB!.prepare('SELECT payload FROM school WHERE id=1').first<{payload:string}>();if(!row)throw new Error('Դպրոցի կարգավորումը բացակայում է։');return JSON.parse(row.payload) as School;}
const digest=async(value:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const publicRequest=(r:RequestRow|null)=>r?{id:r.id,email:r.email,name:r.name,childName:r.child_name,classLabel:r.class_label,status:r.status,createdAt:r.created_at,verifiedAt:r.verified_at,nextSendAt:r.sent_at+60000}:null;
export async function GET(){try{const user=await getChatGPTUser();const ready=mailReady();if(!user)return json({signedIn:false,mailReady:ready});const s=await school();const member=s.members.find(x=>x.email===user.email.toLowerCase()&&(!x.userId||x.userId===user.userId));if(member?.role==='admin'){const all=await env.DB!.prepare('SELECT * FROM parent_requests ORDER BY created_at DESC LIMIT 500').all<RequestRow>();return json({signedIn:true,email:user.email,mailReady:ready,requests:all.results.filter(r=>!s.members.some(m=>m.email===r.email)).map(publicRequest)});}const row=await env.DB!.prepare('SELECT * FROM parent_requests WHERE user_id=?').bind(user.userId).first<RequestRow>();return json({signedIn:true,email:user.email,mailReady:ready,memberRole:member?.role,request:member?.role==='parent'?{...publicRequest(row),status:'approved'}:row?.status==='approved'?{...publicRequest(row),status:'rejected'}:publicRequest(row)});}catch{return json({error:'Տվյալները բեռնել չհաջողվեց։ Կրկին փորձիր։'},500)}}
export async function POST(req:Request){try{if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Անթույլատրելի հարցում։'},403);const user=await getChatGPTUser();const b=await req.json() as any;const s=await school();
if(!user&&b.action==='register'){
 const email=typeof b.email==='string'?b.email.trim().toLowerCase():'';const valid=(x:unknown,max:number)=>typeof x==='string'&&x.trim().length>=2&&x.trim().length<=max;
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||!valid(b.name,150)||!valid(b.childName,150)||!valid(b.classLabel,20)||! /^[1-9]\s*[ա-ֆ]{1,3}$/i.test(b.classLabel))return json({error:'Լրացրու բոլոր դաշտերը ճիշտ։'},400);
 if(!await rateLimit('register:'+(req.headers.get('x-nf-client-connection-ip')||'shared'),20,3600000))return json({error:'Գրանցման փորձերը շատ են։ Փորձիր ավելի ուշ։'},429);
 if(s.members.some(m=>m.email===email)||await env.DB!.prepare('SELECT email FROM accounts WHERE email=?').bind(email).first()||await env.DB!.prepare('SELECT id FROM parent_requests WHERE email=?').bind(email).first())return json({error:'Այս հասցեով հաշիվ կամ հայտ արդեն կա։ Մուտք գործիր կամ դիմիր ադմինին՝ գաղտնաբառ սահմանելու համար։'},409);
 const c=await credential(b.password);const uid='local:'+crypto.randomUUID();await env.DB!.batch([env.DB!.prepare('INSERT INTO accounts (email,user_id,hash,salt,verified) VALUES (?,?,?,?,0)').bind(email,uid,c.hash,c.salt),env.DB!.prepare("INSERT INTO parent_requests (id,user_id,email,name,child_name,class_label,status,created_at) VALUES (?,?,?,?,?,?,'unverified',?)").bind(crypto.randomUUID(),uid,email,b.name.trim(),b.childName.trim(),b.classLabel.replace(/\s/g,''),new Date().toISOString())]);return loginResponse(email,req,{ok:true},1);
}
if(!user)return json({error:'Նախ մուտք գործիր էլ․ հասցեով և գաղտնաբառով։'},401);const member=s.members.find(x=>x.email===user.email.toLowerCase()&&(!x.userId||x.userId===user.userId));
if(b.action==='reject'){if(member?.role!=='admin')return json({error:'Մուտքն արգելված է։'},403);const r=await env.DB!.prepare("UPDATE parent_requests SET status='rejected',otp_hash=NULL,salt=NULL WHERE id=? AND status IN ('pending','unverified') AND NOT EXISTS (SELECT 1 FROM school,json_each(school.payload,'$.members') AS m WHERE json_extract(m.value,'$.email')=parent_requests.email)").bind(b.id).run();if(!r.meta.changes)return json({error:'Հայտը չի գտնվել կամ արդեն մշակված է։'},409);return json({ok:true});}
if(member)return json({error:'Քո հաշվին արդեն դեր է նշանակված։'},409);
const row=await env.DB!.prepare('SELECT * FROM parent_requests WHERE user_id=?').bind(user.userId).first<RequestRow>();
if(b.action==='register'){
 if(row&&row.status!=='unverified')return json({error:'Քո հայտն արդեն ուղարկված է։ Սպասիր ադմինի պատասխանին։'},409);
 const text=(x:unknown,max:number)=>typeof x==='string'&&x.trim().length>=2&&x.trim().length<=max?x.trim():null;
 const name=text(b.name,150),child=text(b.childName,150),label=text(b.classLabel,20);if(!name||!child||!label||! /^[1-9]\s*[ա-ֆ]{1,3}$/i.test(label))return json({error:'Լրացրու անունները և երեխայի դասարանը, օրինակ՝ 9ա։'},400);
 await env.DB!.prepare("INSERT INTO parent_requests (id,user_id,email,name,child_name,class_label,status,created_at) VALUES (?,?,?,?,?,?,'unverified',?) ON CONFLICT(user_id) DO UPDATE SET name=excluded.name,child_name=excluded.child_name,class_label=excluded.class_label WHERE parent_requests.status='unverified'").bind(crypto.randomUUID(),user.userId,user.email.toLowerCase(),name,child,label.replace(/\s/g,''),new Date().toISOString()).run();return json({ok:true});
}
if(!row||row.email!==user.email.toLowerCase())return json({error:'Սկզբում լրացրու գրանցման հայտը։'},400);
if(row.status!=='unverified')return json({error:'Այս հայտի էլ․ փոստի հաստատումն այլևս հասանելի չէ։'},409);
if(b.action==='send'){
 const {key,from,scriptUrl,scriptSecret,scriptReady}=config();if(!mailReady())return json({error:'Նամակների ուղարկման ծառայությունը դեռ միացված չէ։ Կոդ չի ուղարկվել։ Դիմիր դպրոցի ադմինին։'},503);
 const now=Date.now();if(row.sent_at+60000>now)return json({error:'Նոր կոդ կարող ես խնդրել նախորդից 60 վայրկյան անց։'},429);
 if(row.window_start+3600000>now&&row.send_count>=5)return json({error:'Այս ժամվա ուղարկման սահմանաչափը սպառվել է։ Փորձիր ավելի ուշ։'},429);
 const fresh=row.window_start+3600000<=now;const next=crypto.randomUUID();let random:number;do{random=crypto.getRandomValues(new Uint32Array(1))[0]}while(random>=4294000000);const code=String(random%1000000).padStart(6,'0');const hash=await digest(next+':'+code);
 const claim=await env.DB!.prepare("UPDATE parent_requests SET otp_hash=?,salt=?,expires=?,attempts=0,sent_at=?,send_count=?,window_start=? WHERE id=? AND sent_at=? AND status='unverified'").bind(hash,next,now+600000,now,fresh?1:row.send_count+1,fresh?now:row.window_start,row.id,row.sent_at).run();if(!claim.meta.changes)return json({error:'Կոդի մեկ այլ հարցում արդեն ընթացքի մեջ է։'},409);
 try{
 const response=scriptReady?await fetch(scriptUrl!,{method:'POST',headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(25000),body:JSON.stringify({secret:scriptSecret,to:row.email,code,requestId:next})}):await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','Idempotency-Key':`parent-${row.id}-${next}`},signal:AbortSignal.timeout(15000),body:JSON.stringify({from,to:[row.email],subject:'NOVA դպրոց • Էլ․ փոստի հաստատման կոդ',text:`Քո հաստատման կոդը՝ ${code}\n\nԿոդը գործում է 10 րոպե։ Այն ոչ ոքի մի փոխանցիր։\nՀաստատումից հետո հայտը կստուգի դպրոցի ադմինիստրատորը։`})});
 if(!response.ok)throw new Error('Mail provider rejected');const receipt=await response.json() as {ok?:boolean;id?:string};if(scriptReady?(receipt.ok!==true||receipt.id!==next):!receipt.id)throw new Error('Missing mail receipt');
 }catch{await env.DB!.prepare("UPDATE parent_requests SET otp_hash=NULL,salt=NULL,expires=0 WHERE id=? AND salt=?").bind(row.id,next).run();return json({error:'Նամակի ուղարկումը չհաստատվեց։ Ստուգիր էլ․ փոստը և 60 վայրկյան անց նոր կոդ խնդրիր։'},502)}
 return json({ok:true,message:'Կոդն ուղարկված է քո էլ․ փոստին։'});
}
if(b.action==='verify'){
 if(typeof b.code!=='string'||!/^\d{6}$/.test(b.code))return json({error:'Գրիր վեցանիշ կոդը։'},400);
 const now=Date.now();if(!row.otp_hash||!row.salt||row.expires<=now)return json({error:'Կոդը բացակայում է կամ ժամկետանց է։ Խնդրիր նոր կոդ։'},400);
 const attempt=await env.DB!.prepare("UPDATE parent_requests SET attempts=attempts+1 WHERE id=? AND salt=? AND status='unverified' AND attempts<5 AND expires>?").bind(row.id,row.salt,now).run();if(!attempt.meta.changes)return json({error:'Փորձերի քանակը սպառվել է կամ կոդը հնացել է։ Խնդրիր նոր կոդ։'},429);
 const hash=await digest(row.salt+':'+b.code);if(hash!==row.otp_hash)return json({error:'Կոդը սխալ է։'},400);
 const result=await env.DB!.prepare("UPDATE parent_requests SET status='pending',verified_at=?,otp_hash=NULL,salt=NULL,expires=0 WHERE id=? AND salt=? AND status='unverified' AND expires>?").bind(new Date().toISOString(),row.id,row.salt,now).run();if(!result.meta.changes)return json({error:'Կոդն արդեն օգտագործված է կամ փոխվել է։'},409);await env.DB!.prepare('UPDATE accounts SET verified=1 WHERE email=?').bind(row.email).run();return json({ok:true,message:'Էլ․ փոստը հաստատված է։ Հայտը սպասում է ադմինի հաստատմանը։'});
}
return json({error:'Անհայտ գործողություն։'},400);
}catch{return json({error:'Գործողությունը չհաջողվեց։ Փորձիր նորից։'},500)}}
