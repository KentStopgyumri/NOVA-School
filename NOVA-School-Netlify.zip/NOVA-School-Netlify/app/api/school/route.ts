import {env} from '../../../server/runtime';
import {getAppUser as getChatGPTUser} from '../../app-auth';
import type {School,Member} from '../../model';
import {staffName} from '../../staff-name';
import {credential} from '../../teacher-password';
import {assessmentKinds} from '../../model';
export const dynamic='force-dynamic';
const json=(x:unknown,status=200)=>Response.json(x,{status,headers:{'Cache-Control':'no-store'}});
const fail=(s:string)=>{throw new Error(s)};
async function context(){const user=await getChatGPTUser();if(!user)return null; const db=env.DB!;let row=await db.prepare('SELECT payload, revision FROM school WHERE id=1').first<{payload:string;revision:number}>();if(!row)throw new Error('Դպրոցի կարգավորումը բացակայում է։ Դիմիր ադմինին։');const s:School=JSON.parse(row!.payload);const member=s.members.find(m=>m.email===user.email.toLowerCase()&&(!m.userId||m.userId===user.userId));return {user,db,s,member,revision:row!.revision};}
function filtered(s:School,m:Member){
 if(m.role==='admin')return s;
 const assignments=s.assignments.filter(a=>a.memberId===m.id);
 const readOnly=m.role==='student'||m.role==='parent';
 const own=new Set(m.role==='parent'?(m.studentIds||[]):[m.studentId]);
 const students=s.students.filter(x=>readOnly?own.has(x.id):assignments.some(a=>a.classId===x.classId));
 const classes=new Set(students.map(x=>x.classId));
 // A teacher with an empty class still needs their assigned journal.
 if(m.role==='teacher')for(const a of assignments)classes.add(a.classId);
 const canSubject=(classId:string,subjectId:string)=>readOnly||assignments.some(a=>a.classId===classId&&a.subjectId===subjectId);
 return {...s,ownerId:'',members:[m],audit:[],assignments,classes:s.classes.filter(c=>classes.has(c.id)),students,
 marks:s.marks.filter(x=>{const st=students.find(t=>t.id===x.studentId);return st&&canSubject(st.classId,x.subjectId)}),
 lessons:s.lessons.filter(x=>classes.has(x.classId)&&canSubject(x.classId,x.subjectId)),schedule:s.schedule.filter(x=>classes.has(x.classId))};
}
export async function GET(req?:Request){const c=await context();if(!c)return json({error:'Մուտք գործիր քո հաշվով։'},401);if(!c.member)return json({code:'approval_pending',error:'Քո հայտն սպասում է ադմինի հաստատմանը։'},403);if(c.user.verified===false)return json({code:'email_unverified',error:'Նախ հաստատիր էլ․ փոստդ։'},403);return json({state:filtered(c.s,c.member),member:c.member,revision:c.revision});}
export async function POST(req:Request){try{if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Անթույլատրելի հարցում։'},403);const c=await context();if(!c)return json({error:'Մուտք գործիր։'},401);if(!c.member)return json({error:'Մուտքն արգելված է։'},403);if(c.user.verified===false)return json({code:'email_unverified',error:'Նախ հաստատիր էլ․ փոստդ։'},403);const {s,member:m}=c;let passwordChange:{memberId:string;hash:string;salt:string}|null=null;let auditDetails:string|undefined;const b=await req.json() as any;const text=(v:unknown,max=150)=>typeof v==='string'&&v.trim()&&v.trim().length<=max?v.trim():fail('Լրացրու դաշտերը ճիշտ։');const exists=(arr:{id:string}[],id:string)=>arr.some(x=>x.id===id)||fail('Ընտրված գրառումը գոյություն չունի։');const id=crypto.randomUUID();const admin=()=>m.role==='admin'||fail('Այս գործողությունը միայն ադմինն է կատարում։');const assignment=(classId:string,subjectId:string)=>{exists(s.classes,classId);exists(s.subjects,subjectId);if(m.role!=='admin'&&!(m.role==='teacher'&&s.assignments.some(a=>a.memberId===m.id&&a.classId===classId&&a.subjectId===subjectId)))fail('Այս դասարանում այս առարկան խմբագրելու իրավունք չունես։');};const date=()=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date)||!Number.isFinite(Date.parse(b.date)))fail('Ամսաթիվը սխալ է։');return b.date;};
switch(b.action){case 'approveParent':{
 admin();const request=await c.db.prepare("SELECT id,user_id,email,name,status FROM parent_requests WHERE id=?").bind(b.requestId).first<{id:string;user_id:string;email:string;name:string;status:string}>();
 if(!request||request.status!=='pending')fail('Միայն էլ․ փոստը հաստատած ծնողի հայտը կարելի է հաստատել։');
 if(s.members.some(x=>x.email===request!.email))fail('Այս էլ․ հասցեն արդեն հաշիվ ունի։');
 const children=Array.isArray(b.studentIds)?[...new Set(b.studentIds as string[])]:[];
 if(!children.length||children.length>20)fail('Ընտրիր առնվազն մեկ երեխա։');for(const child of children)exists(s.students,child);
 s.members.push({id,name:request!.name,email:request!.email,userId:request!.user_id,role:'parent',studentIds:children});break;
 }
 case 'parentChildren':{admin();const parent=s.members.find(x=>x.id===b.memberId&&x.role==='parent');if(!parent)fail('Ծնողը չի գտնվել։');const children=Array.isArray(b.studentIds)?[...new Set(b.studentIds as string[])]:[];if(!children.length||children.length>20)fail('Ընտրիր առնվազն մեկ երեխա։');for(const child of children)exists(s.students,child);parent!.studentIds=children;break;}
case 'class':{admin();const grade=Number(b.grade),letter=text(b.letter,3).toLowerCase();if(!Number.isInteger(grade)||grade<1||grade>9||! /^[ա-ֆ]{1,3}$/.test(letter))fail('Ընտրիր 1–9 դասարան և հայերեն տառ։');if(s.classes.some(x=>x.grade===grade&&x.letter===letter))fail('Այս դասարանն արդեն կա։');s.classes.push({id,grade,letter});break;}
case 'student':admin();exists(s.classes,b.classId);s.students.push({id,name:text(b.name),classId:b.classId});break;
case 'accountPassword':
case 'teacherPassword':{admin();const t=s.members.find(x=>x.id===b.memberId&&(b.action==='accountPassword'||x.role==='teacher'));if(!t)fail('Ուսուցիչը չի գտնվել։');passwordChange={memberId:t!.id,...await credential(b.password)};t!.passwordSet=true;break;}
case 'member':{admin();const email=text(b.email).toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail('Գրիր ճիշտ էլ․ հասցե։');if(s.members.some(x=>x.email===email))fail('Այս էլ․ հասցեն արդեն գրանցված է։');if(!['teacher','student'].includes(b.role))fail('Ընտրիր դերը։');if(b.role==='student'){exists(s.students,b.studentId);if(s.members.some(x=>x.studentId===b.studentId))fail('Աշակերտն արդեն հաշիվ ունի։');}if(b.role==='teacher')passwordChange={memberId:id,...await credential(b.password)};const name=text(b.name);s.members.push({id,name,email,role:b.role,...(b.role==='teacher'?{username:staffName(name,s.members.map(x=>x.username||'')),passwordSet:true}:{}),...(b.role==='student'?{studentId:b.studentId}:{})});break;}
case 'subject':admin();if(s.subjects.some(x=>x.name===b.name?.trim()))fail('Առարկան արդեն կա։');s.subjects.push({id,name:text(b.name)});break;
case 'assignment':admin();if(!s.members.some(x=>x.id===b.memberId&&x.role==='teacher'))fail('Ընտրիր ուսուցիչ։');exists(s.classes,b.classId);exists(s.subjects,b.subjectId);if(s.assignments.some(x=>x.memberId===b.memberId&&x.classId===b.classId&&x.subjectId===b.subjectId))fail('Նշանակումն արդեն կա։');s.assignments.push({id,memberId:b.memberId,classId:b.classId,subjectId:b.subjectId});break;
case 'lesson':{assignment(b.classId,b.subjectId);const d=date();const item={id,classId:b.classId,subjectId:b.subjectId,date:d,topic:text(b.topic,1000),homework:typeof b.homework==='string'?b.homework.trim().slice(0,3000):''};const old=s.lessons.findIndex(x=>x.classId===b.classId&&x.subjectId===b.subjectId&&x.date===d);if(old>=0)s.lessons[old]={...item,id:s.lessons[old].id};else s.lessons.push(item);break;}
case 'mark':{
 const st=s.students.find(x=>x.id===b.studentId);if(!st)fail('Աշակերտը չի գտնվել։');assignment(st!.classId,b.subjectId);const d=date();
 if(!['','բ','1','2','3','4','5','6','7','8','9','10'].includes(b.value))fail('Ընտրիր 1–10 կամ բացակա։');
 const existing=s.marks.find(x=>x.studentId===b.studentId&&x.subjectId===b.subjectId&&x.date===d);
 if(m.role==='admin'&&!existing)fail('Նոր գնահատականը դնում է ուսուցիչը։ Ադմինը կարող է խմբագրել արդեն դրվածը։');
 const kind=b.value==='բ'?'Բացակայություն':b.kind;
 if(b.value&&b.value!=='բ'&&!assessmentKinds.includes(kind))fail('Ընտրիր գնահատման տեսակը։');
 const now=new Date().toISOString();auditDetails=`${st!.name} · ${d} · ${existing?.value||'—'} → ${b.value||'հեռացված'} · ${kind||existing?.kind||'առանց տեսակի'}`;
 s.marks=s.marks.filter(x=>x!==existing);
 if(b.value)s.marks.push({id:existing?.id||id,studentId:b.studentId,subjectId:b.subjectId,date:d,value:b.value,kind,createdBy:existing?.createdBy||(existing?undefined:m.id),createdByName:existing?.createdByName||(existing?undefined:m.name),createdAt:existing?.createdAt||now,updatedBy:m.id,updatedByName:m.name,updatedAt:now});break;}
case 'schedule':{admin();exists(s.classes,b.classId);exists(s.subjects,b.subjectId);const day=Number(b.day),period=Number(b.period);if(!Number.isInteger(day)||day<1||day>5||!Number.isInteger(period)||period<1||period>8)fail('Սխալ դասաժամ։');s.schedule=s.schedule.filter(x=>!(x.classId===b.classId&&x.day===day&&x.period===period));s.schedule.push({id,classId:b.classId,subjectId:b.subjectId,day,period});break;}
case 'deleteSchedule':admin();s.schedule=s.schedule.filter(x=>x.id!==b.id);break;
case 'revoke':admin();if(b.id===m.id)fail('Քո մուտքը հեռացնել չի կարելի։');s.members=s.members.filter(x=>x.id!==b.id);s.assignments=s.assignments.filter(x=>x.memberId!==b.id);break;
default:fail('Անհայտ գործողություն։');}
s.audit.unshift({id,date:new Date().toISOString(),actor:m.name,action:b.action,...(auditDetails?{details:auditDetails}:{})});s.audit=s.audit.slice(0,500);const result=passwordChange?(await c.db.batch([
 c.db.prepare('UPDATE school SET payload=?, revision=revision+1 WHERE id=1 AND revision=?').bind(JSON.stringify(s),c.revision),
 c.db.prepare("INSERT INTO teacher_credentials (member_id,hash,salt,failed,locked_until,version) SELECT ?,?,?,0,0,1 WHERE EXISTS (SELECT 1 FROM school WHERE json_extract(payload,'$.audit[0].id')=?) ON CONFLICT(member_id) DO UPDATE SET hash=excluded.hash,salt=excluded.salt,failed=0,locked_until=0,version=teacher_credentials.version+1").bind(passwordChange.memberId,passwordChange.hash,passwordChange.salt,id),
 c.db.prepare("INSERT INTO accounts (email,user_id,hash,salt,verified) SELECT ?,?,?,?,1 WHERE EXISTS (SELECT 1 FROM school WHERE json_extract(payload,'$.audit[0].id')=?) ON CONFLICT(email) DO UPDATE SET hash=excluded.hash,salt=excluded.salt,failed=0,locked_until=0,version=accounts.version+1,verified=1").bind(s.members.find(x=>x.id===passwordChange!.memberId)!.email,s.members.find(x=>x.id===passwordChange!.memberId)!.userId||'local:'+passwordChange.memberId,passwordChange.hash,passwordChange.salt,id)

 ]))[0]:b.action==='approveParent'?(await c.db.batch([
 c.db.prepare("UPDATE school SET payload=?, revision=revision+1 WHERE id=1 AND revision=? AND EXISTS (SELECT 1 FROM parent_requests WHERE id=? AND status='pending')").bind(JSON.stringify(s),c.revision,b.requestId),
 c.db.prepare("UPDATE parent_requests SET status='approved',otp_hash=NULL,salt=NULL WHERE id=? AND status='pending' AND EXISTS (SELECT 1 FROM school WHERE json_extract(payload,'$.audit[0].id')=?)").bind(b.requestId,id)
]))[0]:await c.db.prepare('UPDATE school SET payload=?, revision=revision+1 WHERE id=1 AND revision=?').bind(JSON.stringify(s),c.revision).run();if(!result.meta.changes)return json({error:'Տվյալները փոխվել են մեկ այլ օգտատիրոջ կողմից։ Թարմացրու և կրկնիր։'},409);return json({ok:true});}catch(e){return json({error:e instanceof Error?e.message:'Գործողությունը չհաջողվեց։'},400);}}
