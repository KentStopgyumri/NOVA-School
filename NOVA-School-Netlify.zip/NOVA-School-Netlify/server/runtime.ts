import {DB} from './database';
export const env={DB,get NOVA_MAIL_SCRIPT_URL(){return process.env.NOVA_MAIL_SCRIPT_URL},get NOVA_MAIL_SCRIPT_SECRET(){return process.env.NOVA_MAIL_SCRIPT_SECRET},get RESEND_API_KEY(){return process.env.RESEND_API_KEY},get MAIL_FROM(){return process.env.MAIL_FROM}};
